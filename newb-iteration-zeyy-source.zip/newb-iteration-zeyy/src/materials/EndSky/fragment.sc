#ifndef INSTANCING
$input v_texcoord0, v_posTime
#endif

#include <bgfx_shader.sh>

#ifndef INSTANCING
  #include <newb/main.sh>

  SAMPLER2D_AUTOREG(s_SkyTexture);
#endif

void main() {
  #ifndef INSTANCING
    // End skybox cubemap (atlas 3x2), langsung dari texture tanpa fog/gradient
    vec2 uv = nlEndSkyCubeUV(normalize(v_posTime.xyz));
    vec3 color = texture2D(s_SkyTexture, uv).rgb;

    color *= NL_END_SKY_BRIGHTNESS;

    gl_FragColor = vec4(color, 1.0);
  #else
    gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
